from urllib.request import urlopen
from image import determine_image
from extension import non_extension, get_extension
from pickle import dump, load
from os.path import isfile, getsize
from os import listdir


SAMPLE_URL = 'http://h.acfun.tv/t/553505?pn={}'
URL_PREFIX = b'http://h.acfun.tv'
IMAGE_PREFIX = b'<a href=\"/Images/Upload/'
FILENAME = 'image_{}.{}'
CACHE_FILE_NAME = 'url.cache'

# build cache file if not created
if not isfile(CACHE_FILE_NAME):
    file = open(CACHE_FILE_NAME, 'wb')
    dump(set(), file)
    file.close()

# load the cache from the file
print('cache size:', getsize(CACHE_FILE_NAME) / 1000.0, 'kb')
url_cache_out = open(CACHE_FILE_NAME, 'rb')
url_cache = load(url_cache_out)
url_cache_out.close()

# load image count from the file
current_count = 0
image_file_name = [non_extension(filename) for filename in listdir() if 'image_' in filename]
if image_file_name != []:
    current_count = max([int(count[6:]) for count in image_file_name]) + 1

for pn in range(1, 40):
    web_buffer = urlopen(SAMPLE_URL.format(pn))
    image_url = [(URL_PREFIX + url.split(b'\"')[1]).decode('utf-8') for url in web_buffer if IMAGE_PREFIX in url]
    print('Page:', pn)
    for url in image_url:
        if url not in url_cache:
            # open url
            url_buffer = urlopen(url)

            # write to file
            file_buffer = open(FILENAME.format(current_count, get_extension(url)), 'wb')
            file_buffer.write(url_buffer.read())
            file_buffer.close()

            # add to cache
            url_cache.add(url)

            # plus the counter
            print('Image_{} has been saved'.format(current_count))
            current_count += 1
        else:
            print('The picture has already been save to your directionary')

# save the cache
url_cache_in = open(CACHE_FILE_NAME, 'wb')
dump(url_cache, url_cache_in)
url_cache_in.close()
