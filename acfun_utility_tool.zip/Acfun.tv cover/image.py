def test_jpeg(image_data):
    if image_data[6:10] in (b'JFIF', b'Exif'):
        return 'jpeg'

def test_png(image_data):
    if image_data.startswith(b'\211PNG\r\n\032\n'):
        return 'png'

def test_gif(image_data):
    if image_data[:6] in (b'GIF87a', b'GIF89a'):
        return 'gif'

def test_tiff(image_data):
    if image_data[:2] in (b'MM', b'II'):
        return 'tiff'

def test_rgb(image_data):
    if image_data.startswith(b'\001\332'):
        return 'rgb'

function_list = [test_jpeg, test_png, test_gif, test_tiff, test_rgb]
def determine_image(image_data):
    for f in function_list:
        res = f(image_data)
        if res:
            return res
    return
