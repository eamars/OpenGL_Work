def non_extension(in_name):
    out_name = ''
    isExtension = True
    for char in in_name[::-1]:
        if char == '.':
            isExtension = False
            continue
        if not isExtension:
            out_name += char
    return out_name[::-1]
