from urllib.request import urlopen
from image import determine_image
from non_extension import non_extension
from pickle import dump, load
from os.path import isfile, getsize
from os import listdir


CACHE_FILE_NAME = 'image.cache'
NUMBER_OF_IMAGE_PER_TIME = 100


#record last 20 bytes of the image file + first 20 bytes of image
# if the file is non-exist, create a copy
if not isfile(CACHE_FILE_NAME):
    file = open(CACHE_FILE_NAME, 'wb')
    dump(set(), file)
    file.close()

# load the cache from the file
print('cache size:', getsize(CACHE_FILE_NAME) / 1000.0, 'kb')
image_cache_out = open(CACHE_FILE_NAME, 'rb')
image_cache = load(image_cache_out)
image_cache_out.close()

# load image count from the file
current_count = 0
image_file_name = [non_extension(filename) for filename in listdir() if 'image_' in filename]
if image_file_name != []:
    current_count = max([int(count[6:]) for count in image_file_name]) + 1


# Test the given times
filename = 'image_{}.{}'

i = current_count
while i < NUMBER_OF_IMAGE_PER_TIME + current_count:
    # load from internet
    buffer = urlopen('http://wiki.acfun.tv/keyheaders/cover.php')
    image_data = buffer.read()
    hashed_image = hash(image_data)
    if hashed_image not in image_cache:
        # add to cache
        image_cache.add(hashed_image)
        # write to file if the image is not exist
        file = open(filename.format(i, determine_image(image_data)), 'wb')
        file.write(image_data)
        file.close()
        i += 1
    else:
        print('File with hash {} is already existed in your library'.format(hashed_image))
image_cache_in = open(CACHE_FILE_NAME, 'wb')
dump(image_cache, image_cache_in)
image_cache_in.close()
